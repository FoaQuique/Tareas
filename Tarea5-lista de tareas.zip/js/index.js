//variables
var lista= document.getElementById("lista");
var tareaInput= document.getElementById("tareaInput");
var btnNuevaTarea= document.getElementById("btn-agregar");


//Funciones
var agregarTarea= function (){
  var tarea= tareaInput.value;
  var nuevaTarea=document.createElement("li");
  var enlace= document.createElement("a");
  var contenido= document.createTextNode(tarea);
  
  if (tarea === "") {
			tareaInput.setAttribute("placeholder", "Agrega una tarea valida");
			tareaInput.className = "error";
			return false;
		}
  // Agregamos el contenido al enlace
		enlace.appendChild(contenido);
		// Le establecemos un atributo href
		enlace.setAttribute("href", "#");
		// Agrergamos el enlace (a) a la nueva tarea (li)
		nuevaTarea.appendChild(enlace);
		// Agregamos la nueva tarea a la lista
		lista.appendChild(nuevaTarea);
  tareaInput.value = "";
  
	//START STRIKETHROUGH
	// because it's in the function, it only adds it for new items
	function crossOut() {
		nuevaTarea.classList.toggle("done");
	}

  nuevaTarea.addEventListener("click",crossOut);
	//END STRIKETHROUGH
	
// START ADD DELETE BUTTON
	var dBtn = document.createElement("button");
	dBtn.appendChild(document.createTextNode("X"));
	nuevaTarea.appendChild(dBtn);
	dBtn.addEventListener("click", deleteListItem);
	// END ADD DELETE BUTTON


	//ADD CLASS DELETE (DISPLAY: NONE)
	function deleteListItem(){
		nuevaTarea.classList.add("delete")
	}
	//END ADD CLASS DELETE
 
 
  };
var comprobarInput= function (){tareaInput.className = "";
		teareaInput.setAttribute("placeholder", "Agrega tu tarea");
	};
  
 
var eliminarTarea= function (){
		this.parentNode.removeChild(this);
	};
 
 
//Eventos

//agregar tarea
btnNuevaTarea.addEventListener("click", agregarTarea);

// Comprobar Input
	tareaInput.addEventListener("click", comprobarInput);

// Borrando Elementos de la lista
	for (var i = 0; i <= lista.children.length -1; i++) { 
    lista.children[i].addEventListener("click", eliminarTarea);
	}
 
function listaLength(){
	return input.value.length;
} 

function listLength(){
	return lista.length;
}