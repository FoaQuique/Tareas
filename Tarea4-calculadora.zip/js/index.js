//Calculate Tip
function calculateTip() {
  var cuenta = document.getElementById("cuenta").value;
  var calidadServicio = document.getElementById("calidadServicio").value;
  var numPersonas = document.getElementById("personas").value;

  //validate input
  if (cuenta === "" || calidadServicio == 0) {
    alert("Please enter values");
    return;
  }
  //Check to see if this input is empty or less than or equal to 1
  if (numPersonas === "" || numPersonas <= 1) {
    numPersonas = 1;
    document.getElementById("cadUno").style.display = "none";
  } else {
    document.getElementById("cadaUno").style.display = "block";
  }

  //Calculate tip
  var total = (cuenta * calidadServicio) / numPersonas;
  //round to two decimal places
  total = Math.round(total * 100) / 100;
  //next line allows us to always have two digits after decimal point
  total = total.toFixed(2);
  //Display the tip
  document.getElementById("propinaTotal").style.display = "block";
  document.getElementById("propina").innerHTML = total;
}
 



//Hide the tip amount on load
document.getElementById("propinaTotal").style.display = "none";
document.getElementById("cadaUno").style.display = "none";




 
//click to call function
document.getElementById("calculo").onclick = function() {
  calculateTip();

};

//Calculate Tip
function calculateAmount() {
  var cuenta = document.getElementById("cuenta").value;
  var calidadServicio = document.getElementById("calidadServicio").value;
  var numPersonas = document.getElementById("personas").value;
  var uno =1

  //validate input
  if (cuenta === "" || calidadServicio == 0) {
    alert("Please enter values");
    return;
  }
  
//Calculate amount
  var monto = (cuenta*calidadServicio) + parseInt(cuenta);
  //round to two decimal places
  monto = Math.round(monto * 100) / 100;
  //next line allows us to always have two digits after decimal point
   monto = monto.toFixed(2);
  //Display the tip
 
  document.getElementById("montoTotal").style.display = "block";
  document.getElementById("monto").innerHTML = monto;

  var totalCuno = [(cuenta*calidadServicio) + parseInt(cuenta)] / (numPersonas) ;
  //round to two decimal places
  totalCuno= Math.round(totalCuno * 100) / 100;
  //next line allows us to always have two digits after decimal point
   totalCuno = totalCuno.toFixed(2);
  //Display the tip
 
  document.getElementById("montoCadaUno").style.display = "block";
  document.getElementById("mcd").innerHTML = totalCuno;
}

//Hide the tip amount on load 
document.getElementById("montoTotal").style.display = "none";
document.getElementById("montoCadaUno").style.display = "none";


//click to call function
document.getElementById("final").onclick = function() {
  calculateAmount();
}